#!/usr/bin/env python3
"""
OCR Test Sample — Python Source Code
=====================================
This file tests OCR accuracy on typical Python code patterns:
  - Decorators, type hints, f-strings
  - Docstrings, comments, comprehensions
  - Various bracket/operator combinations
"""

from __future__ import annotations

import os
import sys
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

# ==============================================================================
# Constants
# ==============================================================================

MAX_RETRIES: int = 3
TIMEOUT_SEC: float = 30.0
DEFAULT_PORT: int = 8080
BASE_URL: str = "https://api.example.com/v2"
PATTERN: str = r"^[a-zA-Z_][a-zA-Z0-9_]*$"
HEX_COLORS: Dict[str, str] = {
    "red": "#FF0000",
    "green": "#00FF00",
    "blue": "#0000FF",
    "white": "#FFFFFF",
    "black": "#000000",
}


# ==============================================================================
# Data Classes
# ==============================================================================

@dataclass
class RegisterMap:
    """Represents an IC register map entry."""

    name: str
    address: int
    width: int = 32
    reset_value: int = 0
    fields: List[Tuple[str, int, int]] = field(default_factory=list)

    @property
    def hex_address(self) -> str:
        return f"0x{self.address:08X}"

    def __repr__(self) -> str:
        return (
            f"RegisterMap(name={self.name!r}, "
            f"addr={self.hex_address}, "
            f"width={self.width})"
        )


# ==============================================================================
# Functions
# ==============================================================================

def calculate_crc32(data: bytes, poly: int = 0xEDB88320) -> int:
    """Calculate CRC-32 checksum (Castagnoli variant).

    Args:
        data: Input byte sequence.
        poly: Generator polynomial (reflected form).

    Returns:
        32-bit CRC value as unsigned integer.
    """
    crc = 0xFFFFFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ poly
            else:
                crc >>= 1
    return crc ^ 0xFFFFFFFF


def parse_config(path: Union[str, Path]) -> Dict[str, Any]:
    """Load JSON configuration with environment variable expansion.

    Supports ${VAR} and ${VAR:-default} syntax in string values.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")

    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    def _expand(value: Any) -> Any:
        if isinstance(value, str):
            import re
            return re.sub(
                r"\$\{(\w+)(?::-(.*?))?\}",
                lambda m: os.environ.get(m.group(1), m.group(2) or ""),
                value,
            )
        elif isinstance(value, dict):
            return {k: _expand(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [_expand(v) for v in value]
        return value

    return _expand(raw)


def matrix_multiply(
    a: List[List[float]],
    b: List[List[float]],
) -> List[List[float]]:
    """Naive O(n^3) matrix multiplication for test purposes."""
    rows_a, cols_a = len(a), len(a[0])
    rows_b, cols_b = len(b), len(b[0])
    assert cols_a == rows_b, f"Shape mismatch: ({rows_a}x{cols_a}) @ ({rows_b}x{cols_b})"

    result = [[0.0] * cols_b for _ in range(rows_a)]
    for i in range(rows_a):
        for j in range(cols_b):
            result[i][j] = sum(a[i][k] * b[k][j] for k in range(cols_a))
    return result


# ==============================================================================
# Main
# ==============================================================================

if __name__ == "__main__":
    # Quick self-test
    test_data = b"Hello, OCR World! 0123456789 @#$%"
    crc = calculate_crc32(test_data)
    print(f"CRC-32: 0x{crc:08X}")

    regs = [
        RegisterMap("CTRL",   0x0000, fields=[("enable", 0, 0), ("mode", 2, 1)]),
        RegisterMap("STATUS", 0x0004, fields=[("busy", 0, 0), ("error", 1, 1)]),
        RegisterMap("DATA",   0x0008, width=64),
        RegisterMap("IRQ_EN", 0x000C, reset_value=0xFFFFFFFF),
    ]
    for reg in regs:
        print(f"  {reg}")

    sys.exit(0)
