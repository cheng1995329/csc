//==============================================================================
// OCR Test Sample — Verilog RTL
// Module: Simple AXI-Lite register interface
//==============================================================================

`timescale 1ns / 1ps
`default_nettype none

module axi_lite_regs #(
    parameter integer C_S_AXI_DATA_WIDTH = 32,
    parameter integer C_S_AXI_ADDR_WIDTH = 8,
    parameter integer NUM_REGS           = 16,
    parameter [31:0]  RESET_VAL_CTRL     = 32'h0000_0000,
    parameter [31:0]  RESET_VAL_IRQ_EN   = 32'hFFFF_FFFF
)(
    // Clock & Reset
    input  wire                                s_axi_aclk,
    input  wire                                s_axi_aresetn,
    // Write Address Channel
    input  wire [C_S_AXI_ADDR_WIDTH-1:0]       s_axi_awaddr,
    input  wire [2:0]                          s_axi_awprot,
    input  wire                                s_axi_awvalid,
    output wire                                s_axi_awready,
    // Write Data Channel
    input  wire [C_S_AXI_DATA_WIDTH-1:0]       s_axi_wdata,
    input  wire [(C_S_AXI_DATA_WIDTH/8)-1:0]   s_axi_wstrb,
    input  wire                                s_axi_wvalid,
    output wire                                s_axi_wready,
    // Write Response Channel
    output wire [1:0]                          s_axi_bresp,
    output wire                                s_axi_bvalid,
    input  wire                                s_axi_bready,
    // Read Address Channel
    input  wire [C_S_AXI_ADDR_WIDTH-1:0]       s_axi_araddr,
    input  wire [2:0]                          s_axi_arprot,
    input  wire                                s_axi_arvalid,
    output wire                                s_axi_arready,
    // Read Data Channel
    output wire [C_S_AXI_DATA_WIDTH-1:0]       s_axi_rdata,
    output wire [1:0]                          s_axi_rresp,
    output wire                                s_axi_rvalid,
    input  wire                                s_axi_rready,
    // User Ports
    output wire [31:0]                         ctrl_reg,
    output wire [31:0]                         irq_enable,
    input  wire [31:0]                         status_reg,
    output wire                                irq_out
);

    // -------------------------------------------------------------------------
    // Local Parameters
    // -------------------------------------------------------------------------
    localparam ADDR_LSB = (C_S_AXI_DATA_WIDTH / 32) + 1;
    localparam OPT_MEM_ADDR_BITS = $clog2(NUM_REGS) - 1;

    // Register addresses
    localparam [7:0] ADDR_CTRL    = 8'h00;
    localparam [7:0] ADDR_STATUS  = 8'h04;
    localparam [7:0] ADDR_IRQ_EN  = 8'h08;
    localparam [7:0] ADDR_IRQ_STS = 8'h0C;
    localparam [7:0] ADDR_DATA0   = 8'h10;
    localparam [7:0] ADDR_DATA1   = 8'h14;

    // -------------------------------------------------------------------------
    // Register Storage
    // -------------------------------------------------------------------------
    reg [C_S_AXI_DATA_WIDTH-1:0] reg_ctrl;
    reg [C_S_AXI_DATA_WIDTH-1:0] reg_irq_en;
    reg [C_S_AXI_DATA_WIDTH-1:0] reg_irq_sts;
    reg [C_S_AXI_DATA_WIDTH-1:0] reg_data0;
    reg [C_S_AXI_DATA_WIDTH-1:0] reg_data1;

    // -------------------------------------------------------------------------
    // Write Logic
    // -------------------------------------------------------------------------
    always @(posedge s_axi_aclk) begin
        if (!s_axi_aresetn) begin
            reg_ctrl    <= RESET_VAL_CTRL;
            reg_irq_en  <= RESET_VAL_IRQ_EN;
            reg_irq_sts <= 32'h0;
            reg_data0   <= 32'h0;
            reg_data1   <= 32'h0;
        end else if (wr_en) begin
            case (axi_awaddr[7:0])
                ADDR_CTRL:    reg_ctrl    <= s_axi_wdata & 32'h0000_00FF;
                ADDR_IRQ_EN:  reg_irq_en  <= s_axi_wdata;
                ADDR_IRQ_STS: reg_irq_sts <= reg_irq_sts & ~s_axi_wdata;  // W1C
                ADDR_DATA0:   reg_data0   <= s_axi_wdata;
                ADDR_DATA1:   reg_data1   <= s_axi_wdata;
                default: ; // no-op
            endcase
        end
    end

    // -------------------------------------------------------------------------
    // Read Logic
    // -------------------------------------------------------------------------
    always @(*) begin
        case (axi_araddr[7:0])
            ADDR_CTRL:    rd_data = reg_ctrl;
            ADDR_STATUS:  rd_data = status_reg;
            ADDR_IRQ_EN:  rd_data = reg_irq_en;
            ADDR_IRQ_STS: rd_data = reg_irq_sts;
            ADDR_DATA0:   rd_data = reg_data0;
            ADDR_DATA1:   rd_data = reg_data1;
            default:      rd_data = 32'hDEAD_BEEF;
        endcase
    end

    // -------------------------------------------------------------------------
    // Interrupt Logic
    // -------------------------------------------------------------------------
    assign irq_out = |(reg_irq_sts & reg_irq_en);

    // Output assignments
    assign ctrl_reg   = reg_ctrl;
    assign irq_enable = reg_irq_en;

endmodule

`default_nettype wire
